
public class TableRow {

	String symbol;
	int index,address;
	public TableRow(String symbol, int index, int address) {
		super();
		this.symbol = symbol;
		this.index = index;
		this.address = address;
	}
	
	public TableRow(String symbol, int address) {
		this.symbol = symbol;
		this.address = address;
	}

	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public int getAddress() {
		return address;
	}
	public void setAddress(int address) {
		this.address = address;
	}
	
}
