import java.util.*;
import java.io.*;
public class PassOne {
	
	 BufferedReader br;
	 int pooltab_ptr=0,lc=0,littab_ptr=0,ptr=0;
	 int symIndex,litIndex;
	 LinkedHashMap<String, TableRow> symtab;
	 ArrayList<TableRow> littab;
	 ArrayList<Integer> pooltab;
	public PassOne() throws IOException {
		
		br = new BufferedReader(new FileReader("input.asm"));
		lc=0;
		littab = new ArrayList<>();
		pooltab = new ArrayList<>();
		symtab = new LinkedHashMap<>();
		pooltab.add(0);
		litIndex=0;
		symIndex=0;

	}
	public static void main(String[] args) throws IOException {
		
		PassOne passOne = new PassOne();
		try {
			passOne.parseFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void parseFile() throws IOException {
		String line;
		String code;
		BufferedWriter fr = new BufferedWriter(new FileWriter("IC.txt"));
		INSTtable lookup = new INSTtable(); 
		while((line=br.readLine())!=null) {
			String parts[] = line.split("\\s+");
			
			if(!parts[0].isEmpty()) {		/*Processing of Labels*/
				
				if(symtab.containsKey(parts[0]))
					symtab.put(parts[0], new TableRow(parts[0],symtab.get(parts[0]).getIndex(),lc));
				else
					symtab.put(parts[0], new TableRow(parts[0],++symIndex,lc));
				
			}
			if(parts[1].equals("LTORG")) {
				
				ptr=pooltab.get(pooltab_ptr);
				for(int i=ptr;i<littab_ptr;i++) {
					littab.set(i, new TableRow(littab.get(i).getSymbol(),littab.get(i).getIndex(),lc));
					code ="(DL,01)\t(C,"+littab.get(i).getSymbol()+")";
					fr.write(code+"\n");
					lc++;
				}
				pooltab_ptr++;
				pooltab.add(littab_ptr);
				
			}
			if(parts[1].equals("START")) {
				
				lc = eval(parts[2]);
				code = "(AD,01)\t(C,"+lc+")";
				fr.write(code+"\n");
				
			}else if(parts[1].equals("ORIGIN")) {
				lc = eval(parts[2]);
				code = "(AD,03)\t(C,"+lc+")";
				fr.write(code+"\n");
			}
			
			if(parts[1].equals("EQU")) {
				
				int loc = eval(parts[2]);
				if(symtab.containsKey(parts[0]))
					symtab.put(parts[0], new TableRow(parts[0],symtab.get(parts[0]).getIndex(),loc));
				else
					symtab.put(parts[0], new TableRow(parts[0],++symIndex,loc));
				
			}
			if(parts[1].equals("DC")) {
				
				lc++;
				int value = Integer.parseInt(parts[2].replaceAll("'", ""));
				code = "(DL,01)\t(C,"+value+")";
				fr.write(code+"\n");
			
			}else if(parts[1].equals("DS")) {
				
				int value = Integer.parseInt(parts[2].replaceAll("'", ""));
				code = "(DL,02)\t(C,"+value+")";
				lc = lc + value;
				fr.write(code+"\n");
				
			}
			if(lookup.getType(parts[1]).equals("IS")) {
				code = "(IS,0"+lookup.getCode(parts[1])+")\t";
				String code2="";
				int j=2;
				while(j<parts.length) {
					parts[j] = parts[j].replaceAll(",", "");
					if(lookup.getType(parts[j]).equals("RG")) {
						code2 = "(RG,0"+lookup.getCode(parts[j])+")\t";
						
					}else {
						if(parts[j].contains("=")) {
							parts[j] = parts[j].replaceAll("['=]", "");
							littab.add(new TableRow(parts[j],++litIndex,-1));
							code2 = code2 + "(L,"+litIndex+")";
							littab_ptr++;
							
						}else if(symtab.containsKey(parts[j])) {
							int ind = symtab.get(parts[j]).getIndex();
							code2+="(S,"+ind+")";
							
						}else{
							
							symtab.put(parts[j], new TableRow(parts[j],++symIndex,-1));
							code2+="(S."+symIndex+")";
						}
						
					}
					j++;
					
					
				}
				lc++;
				code = code + code2;
				fr.write(code+"\n");
			}
			if(parts[1].equals("END")) {
				System.out.println(littab.get(0).getIndex());
				ptr=pooltab.get(pooltab_ptr);
				for(int i=ptr;i<littab_ptr;i++) {
					littab.set(i, new TableRow(littab.get(i).getSymbol(),littab.get(i).getIndex(),lc));
					code ="(DL,01)\t(C,"+littab.get(i).getSymbol()+")";
					fr.write(code+"\n");
					lc++;
				}
				pooltab_ptr++;
				pooltab.add(littab_ptr);
				code = "(AD,02)";
				fr.write(code+"\n");
				
				
			}
			
		}
		
		System.out.println("Processing of PASS1 successfully done. :)");
		printPool();
		printLit();
		printSymTab();
		fr.close();
		br.close();
	}
	
	public void printPool() throws IOException{
		BufferedWriter bw = new BufferedWriter(new FileWriter("pooltab.txt"));
		System.out.println("POOL TABLE");
		for(int i=0;i<pooltab.size();i++) {
			System.out.println(pooltab.get(i));
			bw.write(pooltab.get(i)+"\n");
		}
		bw.close();
	}
	
	public void printLit() throws IOException{
		BufferedWriter bw = new BufferedWriter(new FileWriter("littab.txt"));
		System.out.println("LITERAL TABLE");
		for(int i=0;i<littab.size();i++) {
			TableRow tr = littab.get(i);
			String temp = tr.getIndex()+"\t"+tr.getSymbol()+"\t"+tr.getAddress()+"\n";
			System.out.print(temp);
			bw.write(temp);
		}
		bw.close();
	}
	public void printSymTab() throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter("symtab.txt"));
		System.out.println("SYMBOL TABLE");
		Iterator<String> itr = symtab.keySet().iterator();
		while(itr.hasNext()) {
			String key = itr.next().toString();
			TableRow tr = symtab.get(key);
			String temp = (tr.getIndex())+"\t"+tr.getSymbol()+"\t"+tr.getAddress()+"\n";
			System.out.print(temp);
			bw.write(temp);
		}
		bw.close();
	}
	public int eval(String s) {
		int temp;
		if(s.contains("+")) {
			String split[] = s.split("\\+");
			temp = symtab.get(split[0]).getAddress() + Integer.parseInt(split[1]);
		}else if(s.contains("-")) {
			String split[] = s.split("\\-");
			temp = symtab.get(split[0]).getAddress() - Integer.parseInt(split[1]);
		}else {
			temp = Integer.parseInt(s);
		}
		return temp;
	}
}
