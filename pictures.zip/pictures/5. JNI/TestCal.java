import java.util.*;

public class TestCal{
	public native int add(int n1, int n2);
	public native int sub(int n1, int n2);
	public native int mult(int n1, int n2);
	public native float div(int n1, int n2);
	
	public static void main(String []args){
	
		TestCal t = new TestCal();
		int ch,n1,n2;
		Scanner sc = new Scanner(System.in);
		while(true){
			System.out.println("\nEnter ID of operation do you want to perform :\n1.Addition\n2.Substraction\n3.Multiplication\n4.Division\n5.Exit\n\n");
			ch = sc.nextInt();
			
			if(ch==5){
				break;
			}
			System.out.print("Enter First Number : ");
			n1 = sc.nextInt();
			System.out.print("Enter Second Number : ");
			n2 = sc.nextInt();
			
		
			switch(ch){
				case 1: System.out.println("\nAddition is "+t.add(n1,n2));
						break;
				case 2: System.out.println("\nSubstraction is "+t.sub(n1,n2));
						break;
				case 3: System.out.println("\nMultiplication is "+t.mult(n1,n2));
						break;
				case 4: System.out.println("\nDivision is "+t.div(n1,n2));
						break;
				default:System.out.println("Enter Valid Operation ID");
						break;
			}
		}
	}
	
	static{
		System.loadLibrary("TestCal");
	}
}
