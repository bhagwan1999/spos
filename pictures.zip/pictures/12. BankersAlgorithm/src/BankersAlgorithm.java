import java.util.*;
public class BankersAlgorithm {
	public static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		
		System.out.println("Enter no. of resources");
		int m = sc.nextInt();
		System.out.println("Enter no. of processes");
		int n = sc.nextInt();
		
		int[][] ALLOCATION = new int[n][m];
		int[][] MAX = new int[n][m];
		int[][] NEED = new int[n][m];
		int[] AVAILABLE = new int[m];
		int[] WORK = new int[m];
		
//		getting value in ALLOCATION MATRIX
		System.out.println("Enter Allocation Matrix");
		getValues(ALLOCATION,n,m);
		
//		getting value in MAX MATRIX
		System.out.println("Enter Maximum Matrix");
		getValues(MAX,n,m);
		
//		getting available Resources
		System.out.println("Enter Available Resources");
		for(int i=0;i<m;i++) {
			AVAILABLE[i] = sc.nextInt();
		}
		
//		Calculating Need Matrix
		NEED = calNeed(ALLOCATION,MAX,n,m);
		
//		display(NEED,n,m);
		
		boolean[] FINISH = new boolean[n];
		for(int i=0;i<n;i++) {
			FINISH[i]=false;
		}
		
		int count=0;
		int[] safeSeq = new int[n];
		boolean found;
		
		while(count<n) {
			found=false;
			for(int i=0;i<n;i++) {
				if(FINISH[i]==false) {
					int j=0;
					for(j=0;j<m;j++) {
						if(NEED[i][j]>AVAILABLE[j]) {
							break;
						}
					}
					if(j==m) {
						for(int k=0;k<m;k++) {
							AVAILABLE[k]+=ALLOCATION[i][k];
						}
						FINISH[i]=true;
						safeSeq[count]=i+1;
						count++;
						found=true;
						
					}
				}
			}
			if(found==false) {
				break;
			}
			
		}
		
		System.out.println("Safe sequence :");
		for(int i=0;i<n;i++) {
			System.out.print(safeSeq[i]+" --> ");
		}
		
	
	}
	public static int[][] calNeed(int arr1[][], int arr2[][], int n, int m) {
		int[][] need = new int[n][m];
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				need[i][j] = arr2[i][j] - arr1[i][j];
			}
		}
		return need;
	}
	
	public static void getValues(int arr[][], int n, int m) {
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				arr[i][j]=sc.nextInt();
			}
		}
	}
	public static void display(int arr[][],int n,int m) {
		System.out.println();
		for(int i=0;i<n;i++) {
			for(int j=0;j<m;j++) {
				System.out.println(arr[i][j]+" ");
			}
			System.out.println();
		}
	}
}
