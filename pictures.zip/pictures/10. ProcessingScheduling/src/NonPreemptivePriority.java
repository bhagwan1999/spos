import java.util.*;
public class NonPreemptivePriority {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of processes : ");
		int numProcess = sc.nextInt();
		
		Process[] process = new Process[numProcess];
		
//		Taking Arrival and Burst time in processes
		for(int i=0;i<numProcess;i++) {
			System.out.println("P("+(i+1)+") : Enter the Arrival, Burst Time and Priority");
			int al = sc.nextInt();
			int bl = sc.nextInt();
			int priority = sc.nextInt();
			process[i] = new Process("P"+(i+1),al,bl,priority);
		}
		Arrays.sort(process, new SortByPriority());
		
		int sum=0,count=0;
		double avgWT=0,avgTAT=0;
		System.out.println("\nName\tAT\tBT\tCT\tTAT\tWT\tPriority");
		System.out.println("\n=================================================================================");
		while(true) {
//			Lowest the value of priority give highest priority
			for(int i=0;i<numProcess;i++) {
				if(!process[i].isCompleted&&process[i].AT<=sum) {
					sum=process[i].CT=sum+process[i].BT;
					process[i].TAT = process[i].CT - process[i].AT;
					process[i].WT = process[i].TAT - process[i].BT;
					avgTAT = avgTAT + process[i].TAT;
					avgWT = avgWT + process[i].WT;
					process[i].isCompleted = true;
					process[i].display();
					count++;
				}
				if(count==numProcess) {
					break;
				}
				
			}
			if(count==numProcess) {
				break;
			}
		}
		
		avgTAT = (double) avgTAT/numProcess;
		avgWT = (double) avgWT/numProcess;
		
		System.out.println("Average Turn Around Time : "+avgTAT);
		System.out.println("Average Waiting Time : "+avgWT);
		
		
	}
}
