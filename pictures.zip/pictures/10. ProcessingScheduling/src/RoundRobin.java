import java.util.*;
public class RoundRobin {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int numProcess;
		System.out.println("Enter no. of processes : ");
		numProcess=sc.nextInt();
		Process[] process = new Process[numProcess];
		System.out.println("Enter Arrival and Burst time of processes");
		for (int i = 0; i < numProcess; i++) {
			System.out.println("P("+(i+1)+") : Enter Arrival and Burst Time");
			int at = sc.nextInt();
			int bt = sc.nextInt();
			process[i] = new Process("P"+(i+1), at, bt);
		}
		int quantum=0;
		Arrays.sort(process, new SortByArrival());
		System.out.println("Enter Quantum Time ;");
		quantum = sc.nextInt();
		int time=0,front=0,back=0,count=0,ptr=0;
		int[] que = new int[1000];
		double avgTAT=0,avgWT=0;
		System.out.println("Name\tAT\tBT\tCT\tTAT\tWT\tpriority");
		System.out.println("---------------------------------------------------------------------------------------");
		for (int i = 0; i < numProcess; i++) {
			if (process[i].AT<=time&&!process[i].isArrive&&!process[i].isCompleted) {
				process[i].isArrive=true;
				que[front]=i;
				front++;
			}
		}
		while (true) {
			if(count==numProcess) {
				break;
			}
			ptr = que[back];
			back++;
			if(process[ptr].remBT<=quantum) {
				
				time = time + process[ptr].remBT;
				process[ptr].remBT=0;
				process[ptr].isCompleted = true;
				process[ptr].CT = time;
				process[ptr].TAT = process[ptr].CT - process[ptr].AT;
				process[ptr].WT = process[ptr].TAT - process[ptr].BT;
				avgTAT = avgTAT + process[ptr].TAT;
				avgWT = avgWT + process[ptr].WT;
				process[ptr].display();
				count++;
				
			}else {
				
				time = time + quantum;
				process[ptr].remBT = process[ptr].remBT - quantum;
				
			}
			for (int i = 0; i < numProcess; i++) {
				if (process[i].AT<=time&&(!process[i].isArrive&&!process[i].isCompleted)) {
					process[i].isArrive=true;
					que[front]=i;
					front++;
				}
			}
			if(!process[ptr].isCompleted) {
				que[front] = ptr;
				front++;
			}
			
		}
		
		avgTAT = (double) avgTAT/numProcess;
		avgWT = (double) avgWT/numProcess;
		System.out.println("Average Turn Around Time : "+avgTAT+"\nAverage Waiting Time : "+avgWT);
	}
}
