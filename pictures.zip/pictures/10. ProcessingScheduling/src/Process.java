import java.util.Comparator;
public class Process {
	
	int WT,CT,BT,remBT,TAT,AT,priority;
	String name;
	boolean isCompleted,isArrival;
	
	public Process(String name, int AT, int BT) {
		this.name=name;
		this.AT=AT;
		this.BT=BT;
		WT=CT=TAT=0;
		priority=0;
		remBT = BT;
		isArrival = false; /*Only Used for Round Robin*/
		isCompleted = false;
	}
	public Process(String name, int AT, int BT, int priority) {
		this.name=name;
		this.AT=AT;
		this.BT=BT;
		WT=CT=TAT=0;
		this.priority=priority;
		isCompleted=false;
	}
	public void display() {
		System.out.println(name+"\t"+AT+"\t"+BT+"\t"+CT+"\t"+TAT+"\t"+WT+"\t"+priority+"\t");
	}

}
class SortByArrival implements Comparator<Process>{

	@Override
	public int compare(Process p1, Process p2) {
		// TODO Auto-generated method stub
		return p1.AT-p2.AT;
	}
	
}
class SortByPriority implements Comparator<Process>{

	@Override
	public int compare(Process p1, Process p2) {
		// TODO Auto-generated method stub
		return p1.priority-p2.priority;
	}
	
}