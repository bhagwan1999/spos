import java.util.*;

public class FCFS {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of processes");
		int numProcess = sc.nextInt();
		Process[] process = new Process[numProcess];
		for(int i=0;i<numProcess;i++) {
			System.out.println("P("+(i+1)+") : Enter Arrival Time and Burst Time ");
			int at = sc.nextInt();
			int bt = sc.nextInt();
			process[i] = new Process("P"+(i+1),at,bt);
		}
		
		Arrays.sort(process, new SortByArrival());
		
		int sum=0;
		double avgWT=0,avgTAT=0;
		System.out.print("\n\nName\tAT\tBT\tCT\tTAT\tWT\tPriority");
		System.out.println("\n==================================================================================================================================");
		
		for(int i=0;i<numProcess;i++) {
			sum=process[i].CT = sum+process[i].BT;
			process[i].TAT = process[i].CT - process[i].AT;
			process[i].WT = process[i].TAT - process[i].BT;
			avgTAT = avgTAT + process[i].TAT;
			avgWT = avgWT + process[i].WT;
			process[i].display();
			
		}
		avgTAT = (double)avgTAT / numProcess;
		avgWT = (double)avgWT / numProcess;
		System.out.println("Average Turn Around Time :"+avgTAT);
		System.out.println("Average Waiting Time : "+avgWT);
	}
	
}
