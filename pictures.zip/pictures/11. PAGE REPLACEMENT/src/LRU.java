import java.util.Scanner;
import java.util.*;

public class LRU {
	public static void main(String []args) {
		boolean isFull=false;
		ArrayList<Integer> stack = new ArrayList<Integer>();
		int frames, search, pointer=0,fault=0,hit=0,ref_len;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of frames");
		frames = sc.nextInt();
		System.out.println("Enter reference length");
		ref_len = sc.nextInt();
		int[] reference = new int[ref_len];
		int[] buffer = new int[frames];
		int[][] mem_layout = new int[frames][ref_len];
		System.out.println("Enter reference string");
		for(int i=0;i<ref_len;i++) {
			reference[i]=sc.nextInt();
		}
		for(int i=0;i<frames;i++) {
			buffer[i]=-1;
		}
		for(int i=0;i<ref_len;i++) {
			if(stack.contains(reference[i])) {
				stack.remove(stack.indexOf(reference[i]));
			}
			stack.add(reference[i]);
			search=-1;
			for(int j=0;j<frames;j++) {
				if(buffer[j]==reference[i]) {
					search=j;
					hit++;
					break;
				}
			}
			if(search==-1) {
				if(isFull) {
					int min_pos=ref_len;
					for(int j=0;j<frames;j++) {
						if(stack.contains(buffer[j])) {
							int temp = stack.indexOf(buffer[j]);
							if(temp<min_pos) {
								min_pos=temp;
								pointer=j;
							}
						}
					}
				}
				buffer[pointer]=reference[i];
				fault++;
				pointer++;
				if(pointer==frames) {
					pointer=0;
					isFull=true;
				}
			}
			for(int j=0;j<frames;j++) {
				mem_layout[j][i]=buffer[j];
			}
			
		}
		
		
		for(int i=0;i<frames;i++) {
			for(int j=0;j<ref_len;j++) {
				System.out.print(mem_layout[i][j]+"\t");
			}
			System.out.println();
			
		}
		System.out.println("No. of Page Faults : "+fault);
		System.out.println("No. of Page Hits : "+hit);
		double hit_ratio = (double) hit/ref_len;
		System.out.println("Hit Ration : "+hit_ratio);
		
		
	}

}