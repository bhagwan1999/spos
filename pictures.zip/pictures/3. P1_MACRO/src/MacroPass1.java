import java.util.*;
import java.io.*;
public class MacroPass1 {
	
	public static void main(String[] args) throws IOException {
		
		BufferedReader br = new BufferedReader(new FileReader("input.txt"));
		FileWriter mnt = new FileWriter("mnt.txt");
		FileWriter mdt = new FileWriter("mdt.txt");
		FileWriter kpdt = new FileWriter("kpdt.txt");
		FileWriter pntab = new FileWriter("pntab.txt");
		FileWriter ir = new FileWriter("intermediate.txt");
		
		LinkedHashMap<String, Integer> pnt = new LinkedHashMap<>();
		int mdtp=1,paramNo=1,kp=0,pp=0,kpdtp=0,flag=0;
		String line;
		String MacroName = null;
		while((line=br.readLine())!=null) {
			
			String parts[]=line.split("\\s+");

//			for handling macro, macro name and there parameter statements
			if(parts[0].equalsIgnoreCase("MACRO")) {
				flag=1;
				line=br.readLine();
				parts = line.split("\\s+");
				MacroName = parts[0];
//				If does not have parameters
				if(parts.length<=1) {
					mnt.write(MacroName+":\t"+pp+"\t"+kp+"\t"+mdtp+"\t"+(kp==0?kpdtp:kpdtp+1)+"\n");
					continue;
				}
//				Parameter Processing
				for(int i=1;i<parts.length;i++) {
					parts[i]=parts[i].replaceAll("[&,]", "");
					
					if(parts[i].contains("=")) {
						++kp;
						String keyParam[] = parts[i].split("=");
						pnt.put(keyParam[0],paramNo++);
						if(keyParam.length==2) {
							kpdt.write(keyParam[0]+"\t"+keyParam[1]+"\n");
						}else {
							kpdt.write(keyParam[0]+"\t-\n");
						}
					}else {
						pnt.put(parts[i],paramNo++);
						pp++;
					}
				}
				mnt.write(MacroName+":\t"+pp+"\t"+kp+"\t"+mdtp+"\t"+(kp==0?kpdtp:(kpdtp+1))+"\n");
				kpdtp = kpdtp + kp;
						
			}else if(parts[0].equalsIgnoreCase("MEND")) { /* For processing of MEND*/
				mdt.write(line+"\n");
				kp=pp=flag=0;
				paramNo=1;
				mdtp++;
				pntab.write(MacroName+":\t");
				Iterator<String> itr = pnt.keySet().iterator();
				while(itr.hasNext()) {
					pntab.write(itr.next()+"\t");
				}
				pntab.write("\n");
				pnt.clear();
			}else if(flag==1) { // For processing of statements in macro
				
				for(int i=0;i<parts.length;i++) {
					if(parts[i].contains("&")) {
						parts[i]=parts[i].replaceAll("[&,]", "");
						mdt.write("(P,"+pnt.get(parts[i])+")\t");
					}else {
						mdt.write(parts[i]+"\t");
					}
				}
				mdt.write("\n");
				mdtp++;
			}else {     //statements other than macro definition
				ir.write(line+"\n");
			}
			
		}
		br.close();
		pntab.close();
		ir.close();
		kpdt.close();
		pntab.close();
		mnt.close();
		mdt.close();
		System.out.println("You Macro Processing is Successfully done. :)");
	}
	
}
