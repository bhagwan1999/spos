import java.util.*;
import java.io.*;

public class PassTwo {

	ArrayList<TableRow> symtab;
	ArrayList<TableRow> littab;
	BufferedReader br;
	BufferedWriter fr;
	public PassTwo() {
		symtab = new ArrayList<>();
		littab = new ArrayList<>();
	}
	public static void main(String[] args) throws IOException {
		PassTwo passTwo = new PassTwo();
		passTwo.generateCode("Pass2.txt");
	}
	public void readTables() throws IOException {
		br = new BufferedReader(new FileReader("symtab.txt"));
		String line;
		while((line=br.readLine())!=null) {
			String split[] = line.split("\\s+");
			symtab.add(new TableRow(split[1],Integer.parseInt(split[0]),Integer.parseInt(split[2])));
		}
		br.close();
		br = new BufferedReader(new FileReader("littab.txt"));
		while((line=br.readLine())!=null) {
			String split[] = line.split("\\s+");
			littab.add(new TableRow(split[1],Integer.parseInt(split[0]),Integer.parseInt(split[2])));
		}
		br.close();
	}
	public void generateCode(String file) throws IOException {
		readTables();
		String line,code;
		br = new BufferedReader(new FileReader("IC.txt"));
		fr = new BufferedWriter(new FileWriter(file));
		while((line=br.readLine())!=null) {
			
			String parts[] = line.split("\\s+");
			
			if(parts[0].contains("AD")||parts[0].contains("DL,02")) {
				
				fr.write("\n");
				continue;
			}else if(parts.length==2) {
				
				if (parts[0].contains("DL")) {
					
					int constant = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
					code = "00\t0\t"+String.format("%03d", constant)+"\n";
					fr.write(code);
					
				}else if(parts[0].contains("IS")) {
					
					int opcode = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
					if(opcode==10||opcode==9) {
						if(parts[1].contains("S")) {
							int symIndex = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
							code = String.format("%02d", opcode)+"\t0\t"+String.format("%03d", symtab.get(symIndex-1).getAddress())+"\n";
							fr.write(code);
						}else if(parts[1].contains("S")) {
							int litIndex = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
							code = String.format("%02d", opcode)+"\t0\t"+String.format("%03d", littab.get(litIndex-1).getAddress())+"\n";
							fr.write(code);
						}
					}
				}
			}else if(parts.length==1 && parts[0].contains("IS")) {
				
				int opcode = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
				code = String.format("%02d", opcode)+"\t0\t"+String.format("%03d", 0)+"\n";
				fr.write(code);
			}else if(parts.length==3 && parts[0].contains("IS")) {
				int opcode = Integer.parseInt(parts[0].replaceAll("[^0-9]", ""));
				int regcode = Integer.parseInt(parts[1].replaceAll("[^0-9]", ""));
				
				if(parts[2].contains("S")) {
					int symIndex = Integer.parseInt(parts[2].replaceAll("[^0-9]", ""));
					code = String.format("%02d", opcode)+"\t"+regcode+"\t"+String.format("%03d", symtab.get(symIndex-1).getAddress())+"\n";
					fr.write(code);
				}else if(parts[2].contains("S")) {
					int litIndex = Integer.parseInt(parts[2].replaceAll("[^0-9]", ""));
					code = String.format("%02d", opcode)+"\t"+regcode+"\t"+String.format("%03d", littab.get(litIndex-1).getAddress())+"\n";
					fr.write(code);
				}
				
			}
		}
		System.out.println("Assembler Pass2 operation is successfully performed. :)");
		br.close();
		fr.close();
		
	}
}
